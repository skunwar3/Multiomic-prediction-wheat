#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 19 14:19:49 2025

@author: sudipkunwar
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_decomposition import PLSRegression

# Define training functions
def train_random_forest(X, y, n_estimators=100):
    model = RandomForestRegressor(n_estimators=n_estimators, random_state=42)
    model.fit(X, y)
    return model

def train_pls_regression(X, y, max_iter=200):
    model = PLSRegression(max_iter=max_iter)
    model.fit(X, y)
    return model

# Function to run predictions and compute consistency index
def run_predictions_with_folds(X, Y, scheme_column, response_columns, models):
    results = []
    top_30_lists = []
    train_data = Y[Y[scheme_column] == 0]
    test_data = Y[Y[scheme_column] == 1]

    X_train_full = X.loc[train_data.index].values
    y_train_full = train_data[response_columns].values
    X_test = X.loc[test_data.index].values
    y_test = test_data[response_columns].values

    for trait_idx, trait in enumerate(response_columns):
        y_train_trait = y_train_full[:, trait_idx]
        y_test_trait = y_test[:, trait_idx]

        # Save top 30 genotypes based on observed values
        top_30_observed = test_data.nlargest(30, trait)[['Year', 'Genotype', trait]].copy()
        top_30_observed['Model'] = 'Observed'
        top_30_observed.rename(columns={trait: 'Value'}, inplace=True)
        top_30_lists.append(top_30_observed)

        for model_name, model_train_func in models.items():
            print(f"  Training {model_name} for {trait}...")
            model = model_train_func(X_train_full, y_train_trait)
            y_pred_test = model.predict(X_test)
            
            test_data[f'Predicted_{trait}_{model_name}'] = y_pred_test
            
            # Rank genotypes
            top_30_predicted = test_data.nlargest(30, f'Predicted_{trait}_{model_name}')[['Year', 'Genotype', f'Predicted_{trait}_{model_name}']].copy()
            top_30_predicted['Model'] = model_name
            top_30_predicted.rename(columns={f'Predicted_{trait}_{model_name}': 'Value'}, inplace=True)
            top_30_lists.append(top_30_predicted)
            
            # Calculate consistency index (CI)
            matching_count = len(set(top_30_observed['Genotype']) & set(top_30_predicted['Genotype']))
            CI = (matching_count / 30) * 100
            
            results.append({
                'Trait': trait,
                'Model': model_name,
                'Matching Genotypes': matching_count,
                'Consistency Index': CI
            })
    
    results_df = pd.DataFrame(results)
    results_df.to_excel('Independent_prediction_results_with_CI.xlsx', index=False)
    top_30_df = pd.concat(top_30_lists, ignore_index=True)
    top_30_df.to_excel('Top_30_Genotypes.xlsx', index=False)
    print("Results saved to Independent_prediction_results_with_CI.xlsx!")
    print("Top 30 genotypes saved to Top_30_Genotypes.xlsx!")
    return results_df

# Example Usage
if __name__ == "__main__":
    try:
        df = pd.read_csv("G_H_W.csv")
        X = df.iloc[:, 1:]
        Y = pd.read_csv("Y.csv")

        scheme_column = "CV"
        response_columns = Y.columns[2:7]

        available_models = {
            'RandomForest': train_random_forest,
            'PLSRegression': train_pls_regression
        }

        selected_models = ['RandomForest', 'PLSRegression']  # Choose models
        valid_models = {name: available_models[name] for name in selected_models if name in available_models}

        if not valid_models:
            raise ValueError("No valid models selected. Please check the model names.")

        print(f"Selected models: {', '.join(valid_models.keys())}")

        results_df = run_predictions_with_folds(X, Y, scheme_column, response_columns, valid_models)

    except Exception as e:
        print(f"An error occurred: {e}")
